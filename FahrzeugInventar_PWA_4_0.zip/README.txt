Fahrzeug-Inventar 4.0 – PWA für Samsung Galaxy Tab

WICHTIG: Eine PWA wird über eine HTTPS-Webadresse installiert (oder lokal als Vorschau geöffnet). Diese ZIP allein ist noch keine direkt installierbare Android-APK und kann nicht einfach über Androids APK-Installer installiert werden.

Einfachster kostenloser Weg zum Online-Stellen:
1. ZIP entpacken.
2. Die Dateien auf einen Webhosting-Dienst hochladen, der HTTPS bereitstellt (z.B. GitHub Pages; dafür GitHub-Konto und Repository erforderlich).
3. Auf dem Tablet die HTTPS-Seite in Chrome öffnen.
4. Chrome-Menü ⋮ > „App installieren“ bzw. „Zum Startbildschirm hinzufügen“.
5. Die App startet dann im eigenen Fenster und ist offline nutzbar, sobald sie einmal geladen wurde.

Daten liegen im lokalen Browser-Speicher (localStorage). Browserdaten nicht löschen; JSON regelmäßig exportieren.
